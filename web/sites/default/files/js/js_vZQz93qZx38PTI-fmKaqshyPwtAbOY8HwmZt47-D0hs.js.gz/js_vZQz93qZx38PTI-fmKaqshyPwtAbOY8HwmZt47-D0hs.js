/**
 * @file
 * silver behaviors.
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.silver = {
    attach: function (context, settings) {

      console.log('It works!');

    }
  };

} (Drupal));
;
